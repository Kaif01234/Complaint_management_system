from __future__ import annotations

import json
import os
import re
import shutil
import sqlite3
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Literal

import joblib
import numpy as np
import torch
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sentence_transformers import SentenceTransformer

ROOT = Path(__file__).resolve().parent
MODELS = ROOT / "models"
DATA_DIR = ROOT / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
MODEL_ZIP = Path(os.getenv("PS26264_MODEL_ZIP", str(MODELS / "PS26264_continued_multilingual_model.zip")))
MODEL_DIR_ENV = os.getenv("PS26264_MODEL_DIR")
CLASSIFIER_PATH = Path(os.getenv("PS26264_CLASSIFIER_PATH", str(MODELS / "PS26264_category_classifier.joblib")))
AUDIT_SUMMARY = Path(os.getenv("PS26264_AUDIT_SUMMARY", str(MODELS / "PS26264_audit_summary.json")))
DB_PATH = Path(os.getenv("VERIFIX_DB_PATH", str(DATA_DIR / "verifix_cases.sqlite3")))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

# Keep local prototype inference predictable on CPU-only student laptops.
torch.set_num_threads(2)
try:
    torch.set_num_interop_threads(1)
except RuntimeError:
    pass


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def db_connect():
    conn = sqlite3.connect(DB_PATH, timeout=20)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    with db_connect() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS cases (
            case_id TEXT PRIMARY KEY,
            institution_id TEXT NOT NULL DEFAULT '',
            institution_name TEXT NOT NULL DEFAULT '',
            bureau TEXT NOT NULL DEFAULT '',
            category TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'Pending',
            received TEXT NOT NULL DEFAULT '',
            data_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS case_events (
            event_id INTEGER PRIMARY KEY AUTOINCREMENT,
            case_id TEXT NOT NULL,
            related_case_id TEXT NOT NULL DEFAULT '',
            event_type TEXT NOT NULL,
            actor TEXT NOT NULL DEFAULT 'System',
            details_json TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL
        )""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_cases_institution ON cases(institution_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_cases_bureau_status ON cases(bureau, status)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_events_case_time ON case_events(case_id, created_at)")


def extract_model() -> Path:
    if MODEL_DIR_ENV:
        p = Path(MODEL_DIR_ENV)
        if (p / "modules.json").exists():
            return p
        raise FileNotFoundError(f"PS26264_MODEL_DIR has no modules.json: {p}")
    extracted = MODELS / "continued_model_extracted"
    if (extracted / "modules.json").exists():
        return extracted
    if not MODEL_ZIP.exists():
        raise FileNotFoundError(f"Continued model ZIP not found: {MODEL_ZIP}")
    extracted.mkdir(parents=True, exist_ok=True)
    if not (extracted / "modules.json").exists():
        with zipfile.ZipFile(MODEL_ZIP) as zf:
            zf.extractall(extracted)
    modules = list(extracted.rglob("modules.json"))
    if not modules:
        raise FileNotFoundError("Selected model ZIP does not contain modules.json.")
    return modules[0].parent


def load_audit_summary() -> dict:
    if not AUDIT_SUMMARY.exists():
        return {}
    try:
        return json.loads(AUDIT_SUMMARY.read_text(encoding="utf-8"))
    except Exception:
        return {}


def load_threshold() -> Optional[float]:
    info = load_audit_summary()
    raw = info.get("similarity_threshold_selection", {}).get("threshold")
    try:
        value = float(raw)
        return value if -1.0 <= value <= 1.0 else None
    except (TypeError, ValueError):
        return None


def normalize_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (value or "").lower())


def case_text(item: dict) -> str:
    text = item.get("complaint_text") or item.get("description") or ""
    summary = item.get("summary") or ""
    return f"{summary} {text}".strip()


def institution_match(a: dict, b: dict):
    id_a = str(a.get("institution_id") or a.get("aicteId") or "").strip()
    id_b = str(b.get("institution_id") or b.get("aicteId") or "").strip()
    name_a = str(a.get("institution") or a.get("institution_name") or "").strip()
    name_b = str(b.get("institution") or b.get("institution_name") or "").strip()
    if id_a and id_b:
        return id_a == id_b, "permanent_id" if id_a == id_b else "permanent_id_mismatch"
    na, nb = normalize_name(name_a), normalize_name(name_b)
    if na and nb and len(na) > 2:
        return na == nb, "normalized_name" if na == nb else "name_mismatch"
    return False, "institution_identity_missing"


def shared_terms(text_a: str, text_b: str):
    stop = {"the", "and", "for", "with", "from", "that", "this", "are", "was", "were", "have", "has", "into", "college", "institute"}
    a = {w.lower() for w in re.findall(r"[A-Za-z]{3,}", text_a) if w.lower() not in stop}
    b = {w.lower() for w in re.findall(r"[A-Za-z]{3,}", text_b) if w.lower() not in stop}
    return sorted(a & b)[:8]


if not CLASSIFIER_PATH.exists():
    raise FileNotFoundError(f"Category classifier not found: {CLASSIFIER_PATH}")
MODEL_PATH = extract_model()
encoder = SentenceTransformer(str(MODEL_PATH), device="cpu")
encoder.max_seq_length = 128
classifier = joblib.load(CLASSIFIER_PATH)
VALIDATION_THRESHOLD = load_threshold()
AUDIT_INFO = load_audit_summary()
init_db()

app = FastAPI(
    title="Verifix — SIH26264 AI Complaint Coordination API",
    version="2.0.0",
    description="Local decision-support service for complaint tracking, multilingual AI similarity, related-case ranking and officer-recorded decisions. No automatic case merging."
)

allowed_origins = [x.strip() for x in os.getenv(
    "CORS_ORIGINS",
    "http://127.0.0.1:5500,http://localhost:5500,http://127.0.0.1:8000,http://localhost:8000"
).split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_methods=["GET", "POST", "PATCH"],
    allow_headers=["*"],
    allow_credentials=False
)


class CasePairRequest(BaseModel):
    case_a: dict
    case_b: dict


class FindRelatedRequest(BaseModel):
    case: dict
    candidate_cases: list[dict] = Field(default_factory=list, max_length=2000)
    top_k: int = Field(default=5, ge=1, le=20)


class PairBatchRequest(BaseModel):
    pairs: list[dict] = Field(default_factory=list, max_length=100)


class PredictRequest(BaseModel):
    complaint_text: str = Field(min_length=3, max_length=10000)


class BulkUpsertRequest(BaseModel):
    cases: list[dict] = Field(default_factory=list, max_length=5000)


class CaseActionRequest(BaseModel):
    status: Optional[str] = Field(default=None, max_length=80)
    bureau: Optional[str] = Field(default=None, max_length=120)
    actor: str = Field(default="AICTE Official", max_length=120)
    remark: str = Field(default="", max_length=2000)


class RelationshipDecisionRequest(BaseModel):
    case_a: str = Field(min_length=1, max_length=100)
    case_b: str = Field(min_length=1, max_length=100)
    decision: Literal["confirm", "dismiss"]
    actor: str = Field(default="Coordination Officer", max_length=120)
    remark: str = Field(default="", max_length=2000)


def classify(text: str):
    vec = encoder.encode([text], convert_to_numpy=True, normalize_embeddings=True, batch_size=1, show_progress_bar=False)
    predicted = str(classifier.predict(vec)[0])
    ranked = []
    if hasattr(classifier, "predict_proba"):
        scores = classifier.predict_proba(vec)[0]
        ranked = [
            {"category": str(label), "score": float(score)}
            for label, score in sorted(zip(classifier.classes_, scores), key=lambda z: z[1], reverse=True)[:3]
        ]
    return predicted, vec[0], ranked


def compose_pair_score(a: dict, b: dict, semantic: float):
    text_a, text_b = case_text(a), case_text(b)
    semantic = float(np.clip(semantic, -1.0, 1.0))
    semantic_unit = float(np.clip(semantic, 0.0, 1.0))
    semantic_pct = int(round(semantic_unit * 100))
    matched, match_type = institution_match(a, b)
    bureau_a, bureau_b = str(a.get("bureau") or ""), str(b.get("bureau") or "")
    category_a, category_b = str(a.get("category") or ""), str(b.get("category") or "")
    cross_bureau = bool(bureau_a and bureau_b and bureau_a != bureau_b)
    same_category = bool(category_a and category_b and category_a == category_b)
    if matched:
        bureau_bonus = 0.08 if cross_bureau else 0.03
        category_bonus = 0.08 if same_category else 0.0
        total = 0.45 + (0.42 * semantic_unit) + bureau_bonus + category_bonus
    else:
        total = 0.75 * semantic_unit
    total_pct = int(round(np.clip(total, 0.0, 0.96) * 100))
    threshold_met = (semantic >= VALIDATION_THRESHOLD) if VALIDATION_THRESHOLD is not None else None
    return {
        "totalPercent": total_pct,
        "entityPercent": 100 if matched else 0,
        "semanticPercent": semantic_pct,
        "semanticCosine": semantic,
        "validationThreshold": VALIDATION_THRESHOLD,
        "thresholdMet": threshold_met,
        "semanticThresholdMet": threshold_met,
        "institutionMatched": matched,
        "institutionMatchType": match_type,
        "crossBureau": cross_bureau,
        "sameCategory": same_category,
        "sharedTerms": shared_terms(text_a, text_b),
        "requiresHumanReview": True,
        "autoMerge": False,
        "scoreMeaning": "Weighted coordination signal; not a probability."
    }


def score_pair(a: dict, b: dict):
    text_a, text_b = case_text(a), case_text(b)
    if not text_a or not text_b:
        semantic = 0.0
    else:
        vectors = encoder.encode([text_a, text_b], convert_to_numpy=True, normalize_embeddings=True, batch_size=2, show_progress_bar=False)
        semantic = float(np.dot(vectors[0], vectors[1]))
    return compose_pair_score(a, b, semantic)


def clean_case(data: dict) -> dict:
    item = dict(data)
    case_id = str(item.get("id") or item.get("case_id") or "").strip()
    if not case_id:
        raise HTTPException(status_code=422, detail="Every case must contain a non-empty id or case_id.")
    item["id"] = case_id
    item.setdefault("linkedCases", [])
    item.setdefault("audit", [])
    item.setdefault("overlapConfirmed", False)
    item.setdefault("confirmedLinkedCases", [])
    item.setdefault("dismissedLinkedCases", [])
    return item


def record_event(conn, case_id: str, event_type: str, actor: str, details: dict, related_case_id: str = ""):
    conn.execute(
        "INSERT INTO case_events(case_id, related_case_id, event_type, actor, details_json, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (case_id, related_case_id, event_type, actor or "System", json.dumps(details, ensure_ascii=False), utc_now())
    )


def _upsert_case(conn, raw: dict):
    item = clean_case(raw)
    case_id = item["id"]
    existing = conn.execute("SELECT data_json, created_at FROM cases WHERE case_id=?", (case_id,)).fetchone()
    now = utc_now()
    json_text = json.dumps(item, ensure_ascii=False)
    institution_id = str(item.get("aicteId") or item.get("institution_id") or "")
    institution_name = str(item.get("institution") or item.get("institution_name") or "")
    conn.execute("""INSERT INTO cases(case_id,institution_id,institution_name,bureau,category,status,received,data_json,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(case_id) DO UPDATE SET institution_id=excluded.institution_id,
        institution_name=excluded.institution_name,bureau=excluded.bureau,category=excluded.category,
        status=excluded.status,received=excluded.received,data_json=excluded.data_json,updated_at=excluded.updated_at""",
        (case_id, institution_id, institution_name, str(item.get("bureau") or ""), str(item.get("category") or ""),
         str(item.get("status") or "Pending"), str(item.get("received") or ""), json_text,
         existing["created_at"] if existing else now, now))
    if existing is None:
        record_event(conn, case_id, "case_created", "Dashboard Sync", {"source": "dashboard"})
        for imported_event in (item.get("audit") or []):
            record_event(conn, case_id, "imported_case_history", str(imported_event.get("actor") or "Historical Record"), imported_event)
    else:
        try:
            old_item = json.loads(existing["data_json"])
            old_audit = old_item.get("audit") or []
            new_audit = item.get("audit") or []
            for event in new_audit[len(old_audit):]:
                record_event(conn, case_id, "case_audit", str(event.get("actor") or "System"), event, "")
        except Exception:
            pass
    return item


@app.get("/api/health")
def health():
    with db_connect() as conn:
        case_count = int(conn.execute("SELECT COUNT(*) FROM cases").fetchone()[0])
        event_count = int(conn.execute("SELECT COUNT(*) FROM case_events").fetchone()[0])
    return {
        "status": "ok", "model_loaded": True, "classifier_loaded": True,
        "device": "cpu", "model_dimension": 384,
        "similarity_threshold_loaded": VALIDATION_THRESHOLD is not None,
        "similarity_threshold": VALIDATION_THRESHOLD,
        "category_count": len(getattr(classifier, "classes_", [])),
        "database": {"engine": "SQLite", "connected": True, "case_count": case_count, "event_count": event_count},
        "note": "Local decision-support prototype. All suggested links require officer verification; no automatic case merge or closure."
    }


@app.get("/api/cases")
def list_cases():
    with db_connect() as conn:
        rows = conn.execute("SELECT data_json FROM cases ORDER BY case_id DESC").fetchall()
    cases = []
    for row in rows:
        try:
            cases.append(json.loads(row["data_json"]))
        except Exception:
            continue
    return {"count": len(cases), "cases": cases, "storage": "SQLite"}


@app.post("/api/cases/bulk-upsert")
def bulk_upsert_cases(payload: BulkUpsertRequest):
    saved = 0
    with db_connect() as conn:
        for raw in payload.cases:
            _upsert_case(conn, raw)
            saved += 1
    return {"status": "saved", "saved": saved, "storage": "SQLite"}


@app.post("/api/cases/replace")
def replace_case_registry(payload: BulkUpsertRequest):
    """Replace the local demo registry, used only by the explicit Reset Demo Data action."""
    with db_connect() as conn:
        previous_count = int(conn.execute("SELECT COUNT(*) FROM cases").fetchone()[0])
        conn.execute("DELETE FROM cases")
        for raw in payload.cases:
            _upsert_case(conn, raw)
        record_event(conn, "*", "demo_registry_reset", "Dashboard Admin",
                     {"previous_case_count": previous_count, "new_case_count": len(payload.cases)})
    return {"status": "replaced", "previous_case_count": previous_count,
            "saved": len(payload.cases), "storage": "SQLite"}


@app.post("/api/cases")
def create_case(payload: dict):
    with db_connect() as conn:
        item = _upsert_case(conn, payload)
    return {"status": "saved", "case": item}


@app.patch("/api/cases/{case_id}")
def patch_case(case_id: str, patch: dict):
    with db_connect() as conn:
        row = conn.execute("SELECT data_json FROM cases WHERE case_id=?", (case_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Case not found.")
        item = json.loads(row["data_json"])
        for key in ("status", "bureau", "priority", "category", "summary", "description"):
            if key in patch:
                item[key] = patch[key]
        actor = str(patch.get("actor") or "AICTE Official")
        item.setdefault("audit", []).append({"time": utc_now(), "actor": actor, "note": str(patch.get("remark") or "Case record updated.")})
        _upsert_case(conn, item)
        record_event(conn, case_id, "case_updated", actor, patch)
    return {"status": "updated", "case": item}


@app.post("/api/cases/{case_id}/action")
def case_action(case_id: str, payload: CaseActionRequest):
    with db_connect() as conn:
        row = conn.execute("SELECT data_json FROM cases WHERE case_id=?", (case_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Case not found.")
        item = json.loads(row["data_json"])
        old_status, old_bureau = item.get("status"), item.get("bureau")
        if payload.status is not None:
            item["status"] = payload.status
        if payload.bureau is not None:
            item["bureau"] = payload.bureau
        note = f"Status: {old_status} → {item.get('status')}. Bureau: {old_bureau} → {item.get('bureau')}. {payload.remark}".strip()
        item.setdefault("audit", []).append({"time": utc_now(), "actor": payload.actor, "note": note})
        _upsert_case(conn, item)
        record_event(conn, case_id, "case_action", payload.actor, {"status": item.get("status"), "bureau": item.get("bureau"), "remark": payload.remark})
    return {"status": "updated", "case": item}


@app.post("/api/relationships/decision")
def relationship_decision(payload: RelationshipDecisionRequest):
    if payload.case_a == payload.case_b:
        raise HTTPException(status_code=422, detail="A case cannot be related to itself.")
    with db_connect() as conn:
        rows = {}
        for case_id in (payload.case_a, payload.case_b):
            row = conn.execute("SELECT data_json FROM cases WHERE case_id=?", (case_id,)).fetchone()
            if not row:
                raise HTTPException(status_code=404, detail=f"Case not found: {case_id}")
            rows[case_id] = json.loads(row["data_json"])
        a, b = rows[payload.case_a], rows[payload.case_b]
        if payload.decision == "confirm":
            for item, other_id in ((a, payload.case_b), (b, payload.case_a)):
                if other_id not in item.setdefault("linkedCases", []): item["linkedCases"].append(other_id)
                if other_id not in item.setdefault("confirmedLinkedCases", []): item["confirmedLinkedCases"].append(other_id)
                item["dismissedLinkedCases"] = [x for x in item.get("dismissedLinkedCases", []) if x != other_id]
                item["overlapConfirmed"] = True
            note = f"Officer confirmed coordination relationship between {payload.case_a} and {payload.case_b}. {payload.remark}".strip()
            event_type = "relationship_confirmed"
        else:
            for item, other_id in ((a, payload.case_b), (b, payload.case_a)):
                item["linkedCases"] = [x for x in item.get("linkedCases", []) if x != other_id]
                item["confirmedLinkedCases"] = [x for x in item.get("confirmedLinkedCases", []) if x != other_id]
                if other_id not in item.setdefault("dismissedLinkedCases", []): item["dismissedLinkedCases"].append(other_id)
                item["overlapConfirmed"] = bool(item["confirmedLinkedCases"])
            note = f"Officer dismissed proposed relationship between {payload.case_a} and {payload.case_b}. {payload.remark}".strip()
            event_type = "relationship_dismissed"
        stamp = utc_now()
        for item in (a, b):
            item.setdefault("audit", []).append({"time": stamp, "actor": payload.actor, "note": note})
            _upsert_case(conn, item)
        record_event(conn, payload.case_a, event_type, payload.actor, {"decision": payload.decision, "remark": payload.remark}, payload.case_b)
        record_event(conn, payload.case_b, event_type, payload.actor, {"decision": payload.decision, "remark": payload.remark}, payload.case_a)
    return {"status": "recorded", "decision": payload.decision, "case_a": a, "case_b": b, "auto_merge": False}


@app.get("/api/audit")
def list_audit(limit: int = 200, case_id: Optional[str] = None):
    limit = max(1, min(int(limit), 1000))
    with db_connect() as conn:
        if case_id:
            rows = conn.execute("SELECT * FROM case_events WHERE case_id=? ORDER BY event_id DESC LIMIT ?", (case_id, limit)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM case_events ORDER BY event_id DESC LIMIT ?", (limit,)).fetchall()
    return {"events": [{"event_id": r["event_id"], "case_id": r["case_id"], "related_case_id": r["related_case_id"], "event_type": r["event_type"], "actor": r["actor"], "details": json.loads(r["details_json"]), "created_at": r["created_at"]} for r in rows]}


@app.get("/api/metrics")
def metrics():
    with db_connect() as conn:
        total = int(conn.execute("SELECT COUNT(*) FROM cases").fetchone()[0])
        statuses = {r["status"]: r["n"] for r in conn.execute("SELECT status, COUNT(*) AS n FROM cases GROUP BY status")}
        bureaus = {r["bureau"]: r["n"] for r in conn.execute("SELECT bureau, COUNT(*) AS n FROM cases GROUP BY bureau")}
        categories = {r["category"]: r["n"] for r in conn.execute("SELECT category, COUNT(*) AS n FROM cases GROUP BY category")}
        events = int(conn.execute("SELECT COUNT(*) FROM case_events").fetchone()[0])
    return {"total_cases": total, "statuses": statuses, "bureaus": bureaus, "categories": categories, "audit_events": events, "storage": "SQLite"}


@app.post("/api/check-overlap")
def check_overlap(payload: CasePairRequest):
    """Exact contract expected by the uploaded dashboard's similarity sandbox."""
    return score_pair(payload.case_a, payload.case_b)


@app.post("/api/score-pairs")
def score_pairs(payload: PairBatchRequest):
    """Batch-score dashboard relationship candidates with one encoder pass."""
    valid = []
    for pair in payload.pairs:
        a, b = pair.get("case_a"), pair.get("case_b")
        if isinstance(a, dict) and isinstance(b, dict):
            valid.append((a, b))
    if not valid:
        return {"results": [], "validation_threshold": VALIDATION_THRESHOLD}
    all_texts = []
    for a, b in valid:
        all_texts.extend([case_text(a), case_text(b)])
    vectors = encoder.encode(all_texts, convert_to_numpy=True, normalize_embeddings=True,
                             batch_size=32, show_progress_bar=False)
    results = []
    for idx, (a, b) in enumerate(valid):
        cosine = float(np.dot(vectors[2 * idx], vectors[2 * idx + 1]))
        results.append(compose_pair_score(a, b, cosine))
    return {"results": results, "count": len(results), "validation_threshold": VALIDATION_THRESHOLD,
            "score_meaning": "Weighted coordination signal; not a probability."}


@app.post("/api/predict-category")
def predict_category(payload: PredictRequest):
    predicted, _, top = classify(payload.complaint_text.strip())
    return {
        "predicted_category": predicted,
        "top_categories": top,
        "category_taxonomy": "17-class synthetic training taxonomy",
        "scores_are_calibrated_probabilities": False,
        "note": "Suggestion only. Does not overwrite the dashboard's selected operational category."
    }


@app.post("/api/find-related")
def find_related(payload: FindRelatedRequest):
    """Rank institution-matched cases using the fine-tuned encoder; never auto-link or merge."""
    draft = payload.case
    candidates = []
    draft_id = str(draft.get("id") or draft.get("case_id") or "")
    dismissed_ids = set(str(x) for x in (draft.get("dismissedLinkedCases") or []))
    confirmed_ids = set(str(x) for x in (draft.get("confirmedLinkedCases") or []))
    for candidate in payload.candidate_cases:
        candidate_id = str(candidate.get("id") or candidate.get("case_id") or "")
        candidate_dismissed = set(str(x) for x in (candidate.get("dismissedLinkedCases") or []))
        candidate_confirmed = set(str(x) for x in (candidate.get("confirmedLinkedCases") or []))
        # Respect the officer's previous decision: do not repeatedly re-suggest a
        # dismissed pair or show an already-confirmed pair as a fresh alert.
        if candidate_id in dismissed_ids or candidate_id in confirmed_ids or draft_id in candidate_dismissed or draft_id in candidate_confirmed:
            continue
        matched, match_type = institution_match(draft, candidate)
        if matched:
            candidates.append((candidate, match_type))

    draft_text = case_text(draft)
    predicted_category = None
    top_categories = []
    if draft_text:
        predicted_category, _, top_categories = classify(draft_text)

    if not candidates or not draft_text:
        return {
            "predicted_category": predicted_category,
            "top_categories": top_categories,
            "candidate_count_same_institution": len(candidates), "matches": [],
            "validation_threshold": VALIDATION_THRESHOLD,
            "threshold_calibrated": VALIDATION_THRESHOLD is not None,
            "human_review_required": True, "auto_merge": False
        }

    texts = [case_text(c) for c, _ in candidates]
    usable = [(candidate, match_type, text) for (candidate, match_type), text in zip(candidates, texts) if text]
    rows = []
    if usable:
        vectors = encoder.encode(
            [draft_text] + [x[2] for x in usable], convert_to_numpy=True,
            normalize_embeddings=True, batch_size=16, show_progress_bar=False
        )
        query_vector = vectors[0]
        for idx, (candidate, match_type, _) in enumerate(usable, start=1):
            semantic = float(np.clip(np.dot(query_vector, vectors[idx]), -1.0, 1.0))
            scored = compose_pair_score(draft, candidate, semantic)
            threshold_met = (semantic >= VALIDATION_THRESHOLD) if VALIDATION_THRESHOLD is not None else None
            rows.append({
                "case_id": str(candidate.get("case_id") or candidate.get("id") or ""),
                "institution_id": str(candidate.get("institution_id") or candidate.get("aicteId") or ""),
                "institution": candidate.get("institution") or candidate.get("institution_name") or "",
                "category": candidate.get("category"), "bureau": candidate.get("bureau"),
                "status": candidate.get("status"), "summary": case_text(candidate)[:180],
                "similarity_score": semantic,
                "similarity_percent": int(round(np.clip(semantic, 0.0, 1.0) * 100)),
                "total_percent": scored["totalPercent"], "threshold_met": threshold_met,
                "validation_threshold": VALIDATION_THRESHOLD,
                "institution_match_type": match_type,
                "same_category": scored["sameCategory"], "cross_bureau": scored["crossBureau"],
                "shared_terms": scored["sharedTerms"],
                "requires_human_review": True, "auto_merge": False
            })
    rows.sort(key=lambda r: (r["threshold_met"] is True, r["total_percent"], r["similarity_score"]), reverse=True)
    if VALIDATION_THRESHOLD is not None:
        above_threshold = [r for r in rows if r["threshold_met"] is True]
        below_threshold = [r for r in rows if r["threshold_met"] is False]
    else:
        # Without a loaded threshold, the API can only return uncalibrated ranked candidates.
        above_threshold, below_threshold = rows, []
    return {
        "predicted_category": predicted_category, "top_categories": top_categories,
        "category_taxonomy": "17-class synthetic training taxonomy",
        "candidate_count_same_institution": len(candidates),
        "matches": above_threshold[:payload.top_k],
        "below_threshold_candidates": below_threshold[:payload.top_k],
        "validation_threshold": VALIDATION_THRESHOLD,
        "threshold_calibrated": VALIDATION_THRESHOLD is not None,
        "human_review_required": True, "auto_merge": False,
        "note": "Only candidates meeting the synthetic validation threshold are returned as suggestions. Below-threshold records are shown separately. Threshold is not real-world validated; officers must verify every suggestion. Scores are not probabilities."
    }
